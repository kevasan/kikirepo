import React, { useEffect, useReducer, useState } from "react";

const initialstate = 0;
const reducer = (state, action) => {
  switch (action) {
    case "plus":
      return state + 1;
    case "minus":
      return state + 1;
    case "reset":
      return initialstate;
    default:
      return state;
  }
};
function TestComponent() {
  const [count, dispatch] = useReducer(reducer, initialstate);
  return (
    <div>
      <button
        onClick={() => {
          dispatch("plus");
        }}
      >
        Click me{count}
      </button>
      <button
        onClick={() => {
          dispatch("minus");
        }}
      >
        Click me {count}
      </button>
    </div>
  );
}

export default TestComponent;
