import React, { useEffect } from "react";

const useCommontitle = (props) => {
  useEffect(() => {
    document.title = `clicking count : ${props.count}`;
  });
};
export default useCommontitle;
