import React, { useEffect, useState } from "react";
import useCommontitle from "./Commontitle";

const Titletwo = () => {
  const [count, setCount] = useState(0);
  useCommontitle(count);
  return (
    <div>
      <button
        onClick={() => {
          setCount(count + 1);
        }}
      >
        Click me two: {count}
      </button>
    </div>
  );
};
export default Titletwo;
