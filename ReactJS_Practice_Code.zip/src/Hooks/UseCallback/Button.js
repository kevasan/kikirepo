import React from "react";

const Button = (props) => {
  console.log("Button Clicked");
  return <button onClick={props.handleClick}>{props.children}</button>;
};
export default Button;
