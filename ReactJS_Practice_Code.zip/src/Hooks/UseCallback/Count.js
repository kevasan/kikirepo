import React from "react";

const Count = (props) => {
  console.log(`Incremented - ${props.text}`);
  return (
    <div>
      {props.text} :: {props.count}
    </div>
  );
};
export default Count;
