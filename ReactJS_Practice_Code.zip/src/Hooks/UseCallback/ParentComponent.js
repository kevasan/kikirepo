import React, { useState, useCallback } from "react";
import Title from "./Title.js";
import Count from "./Count.js";
import Button from "./Button.js";

const ParentComponent = () => {
  const [age, setAge] = useState(25);
  const [salary, incrementSalary] = useState(25000);

  const increaseAge = useCallback(() => {
    setAge(age + 1);
  }, [age]);

  const increaseSalary = useCallback(() => {
    incrementSalary(salary + 10000);
  }, [salary]);

  return (
    <div>
      <Title />
      <Count text="age" count={age}></Count>
      <Button handleClick={increaseAge}>INCREASE AGE NOW</Button>
      <Count text="salary" count={salary}></Count>
      <Button handleClick={increaseSalary}>INCREASE SALARY NOW</Button>
    </div>
  );
};
export default ParentComponent;
