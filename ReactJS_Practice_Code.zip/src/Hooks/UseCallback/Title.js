import React from "react";

const Title = () => {
  console.log("Title Rendered");
  return <h1>Title Component</h1>;
};

export default Title;
