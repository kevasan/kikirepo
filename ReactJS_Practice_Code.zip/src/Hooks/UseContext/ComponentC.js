import React from "react";
import ComponentE from "./ComponentE.js";

const ComponentC = () => {
  return <ComponentE />;
};
export default ComponentC;
