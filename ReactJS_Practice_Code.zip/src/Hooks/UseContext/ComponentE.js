import React from "react";
import ComponentF from "./ComponentF.js";

const ComponentE = () => {
  return <ComponentF />;
};

export default ComponentE;
