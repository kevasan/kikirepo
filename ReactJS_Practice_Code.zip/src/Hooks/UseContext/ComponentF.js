import React, { useContext } from "react";
import { UserContext } from "./UserContext.js";

function ComponentF() {
  const username = useContext(UserContext);
  return <div>Name : {username}</div>;
}

export default ComponentF;
