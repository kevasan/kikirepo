import React, { useState, useEffect } from "react";

const ConditionalEffect = () => {
  const [count, setCount] = useState(0);
  const [name, setName] = useState("");
  useEffect(() => {
    console.log("Updating Effect");
    document.title = `You have clicked ${count} times`;
  }, [count, name]);
  return (
    <div>
      <input
        type="text"
        value={name}
        onChange={(event) => {
          setName(event.target.value);
        }}
      />
      <button
        onClick={() => {
          setCount(count + 1);
        }}
      >
        Click me {count} - ConditionalEffect
      </button>
    </div>
  );
};

export default ConditionalEffect;
