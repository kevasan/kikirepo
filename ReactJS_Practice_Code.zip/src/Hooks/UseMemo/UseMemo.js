import React, { useMemo, useState } from "react";

const UseMemo = () => {
  const [countone, setCountOne] = useState(0);
  const [counttwo, setCountTwo] = useState(0);

  const FuncOne = () => {
    setCountOne(countone + 1);
  };
  const FuncTwo = () => {
    setCountTwo(counttwo + 1);
  };

  const isEven = useMemo(() => {
    let i = 0;
    while (i < 2000) i++;
    return countone % 2 === 0;
  }, [countone]);
  return (
    <div>
      <div>
        <button onClick={FuncOne}>Memo Click One : {countone}</button>
        <span>{isEven ? "Even" : "Odd"}</span>
      </div>
      <button onClick={FuncTwo}>Memo Click Two : {counttwo}</button>
    </div>
  );
};
export default UseMemo;
