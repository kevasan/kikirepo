import React, { useReducer } from "react";

const initialstate = 0;
const reducer = (state, action) => {
  switch (action) {
    case "plus":
      return state + 1;
    case "minus":
      return state - 1;
    case "reset":
      return initialstate;
    default:
      return state;
  }
};

function Count() {
  const [count, dispatch] = useReducer(reducer, initialstate);
  return (
    <div>
      <button onClick={() => dispatch("plus")}>plus {count}</button>
      <button onClick={() => dispatch("minus")}>minus {count}</button>
      <button onClick={() => dispatch("reset")}>reset {count}</button>
    </div>
  );
}

export default Count;
