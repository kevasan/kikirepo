import React, { useState } from "react";
const ObjectState = () => {
  const [name, setName] = useState({ firstName: "", lastName: "" });
  return (
    <div>
      <form>
        <label>Username</label>
        <input
          type="text"
          value={name.firstName}
          onChange={(event) =>
            setName({ ...name, firstName: event.target.value })
          }
        />
        <label>lastName</label>
        <input
          type="text"
          value={name.lastName}
          onChange={(event) =>
            setName({ ...name, lastName: event.target.value })
          }
        />
        <h1>FIRSTNAME: {name.firstName}</h1>
        <h1>LASTNAME : {name.lastName}</h1>
      </form>
    </div>
  );
};
export default ObjectState;
