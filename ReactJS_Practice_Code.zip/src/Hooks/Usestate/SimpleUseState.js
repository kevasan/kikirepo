import React, { useState } from "react";
const SimpleUseState = () => {
  const [count, incrementCount] = useState(0);

  return (
    <button
      onClick={() => {
        incrementCount(count + 1);
      }}
    >
      Click me {count} times
    </button>
  );
};
export default SimpleUseState;
