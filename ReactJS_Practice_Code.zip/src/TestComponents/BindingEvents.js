import React, { Component } from "react";

class BindingEvent1 extends Component {
  clickHandler = () => {
    alert("Binding Events : Way 1 : using bind keyword");
  };
  render() {
    return (
      <div>
        <button onClick={this.clickHandler.bind(this)}>
          Binding Events way 1 : Using bind method
        </button>
      </div>
    );
  }
}

class BindingEvent2 extends Component {
  constructor(props) {
    super(props);
    this.clickHandler = this.clickHandler.bind(this);
  }

  clickHandler = () => {
    alert("way 2 : as props: executed successfully");
  };
  render() {
    return (
      <div>
        <button onClick={this.clickHandler}>
          Binding Events : way 2 : as props
        </button>
      </div>
    );
  }
}

class BindingEvent3 extends Component {
  clickHandler() {
    alert("Hey way 3: Arrow Funtions");
  }

  render() {
    return (
      <div>
        <button onClick={() => this.clickHandler()}>
          Way 3 : BindingEvent3
        </button>
      </div>
    );
  }
}

export { BindingEvent1, BindingEvent2, BindingEvent3 };
