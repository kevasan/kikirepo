import React, { Component } from "react";

class ClassEventHandling extends Component {
  ClassEvent = () => {
    alert("Class Event Handling Executed Successfully...");
  };
  render() {
    return (
      <div>
        <button onClick={this.ClassEvent}>Class Event Handling</button>
      </div>
    );
  }
}
export default ClassEventHandling;
