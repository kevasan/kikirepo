import React, { Component } from "react";

class DestructureClassProps extends Component {
  render() {
    const { fruitName, price } = this.props;
    return (
      <div>
        <h1>
          Destructuring props with class components : {fruitName},{price}
        </h1>
      </div>
    );
  }
}

export default DestructureClassProps;
