import React from "react";

const DestructureFunctionalProps1 = ({ name, location }) => {
  return (
    <div>
      <h1>
        Way 1: Destructuring functional props : {name} and {location}
      </h1>
    </div>
  );
};

const DestructureFunctionalProps2 = (props) => {
  const { name, location } = props;
  return (
    <div>
      <h1>
        Way 2 : Destructuring props : {name} and {location}
      </h1>
    </div>
  );
};
export { DestructureFunctionalProps1, DestructureFunctionalProps2 };
