import React from "react";

const FunctionalEventHandling = () => {
  const FunctionalEvent = () => {
    alert("Functional Event Handling Executed Successfully");
  };
  return (
    <div>
      <button onClick={FunctionalEvent}>Functional Click Event</button>
    </div>
  );
};
export default FunctionalEventHandling;
