import React, { Component } from "react";

class SimpleClass extends Component {
  render() {
    return (
      <div>
        <h1>Hello, This is my first class component for testings</h1>
      </div>
    );
  }
}
export default SimpleClass;
