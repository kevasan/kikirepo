import React, { Component } from "react";
class SimpleClassProps extends Component {
  render() {
    return (
      <div>
        <h1>
          Hey this is my simple class props testing code and prop is :{" "}
          {this.props.heroName}
        </h1>
      </div>
    );
  }
}
export default SimpleClassProps;
