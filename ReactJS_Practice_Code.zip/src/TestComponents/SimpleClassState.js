import React, { Component } from "react";

class SimpleClassState extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "Vishwas"
    };
  }
  render() {
    return (
      <div>
        <h1>
          This is my simple state with class components and the state value is :{" "}
          {this.state.name}
        </h1>
      </div>
    );
  }
}
export default SimpleClassState;
