import React from "react";

const SimpleFunctional = () => {
  return (
    <div>
      <h1>Hello, This is my first functional component for testing purpose</h1>
    </div>
  );
};
export default SimpleFunctional;
