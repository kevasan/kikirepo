import React from "react";

const SimpleFunctionalProps = (props) => {
  return (
    <div>
      <h1>
        Hey this is my simple functional props testing and the prop value is :{" "}
        {props.name}
      </h1>
    </div>
  );
};
export default SimpleFunctionalProps;
