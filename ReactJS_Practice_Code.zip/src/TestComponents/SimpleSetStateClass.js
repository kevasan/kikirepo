import React, { Component } from "react";

class SimpleSetStateClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "This is my simple set state with class component"
    };
  }

  changeText = () => {
    this.setState({
      message: "Thank you for checking set state"
    });
  };

  render() {
    return (
      <div>
        <h1>{this.state.message}</h1>
        <button onClick={this.changeText}>click me to check set state</button>
      </div>
    );
  }
}
export default SimpleSetStateClass;
