import { StrictMode } from "react";
import ReactDOM from "react-dom";

import App from "./App";
import SimpleUseState from "./Hooks/Usestate/SimpleUseState";
import PrevState from "./Hooks/Usestate/PrevState";
import ObjectState from "./Hooks/Usestate/ObjectState";
import SimpleUseEffect from "./Hooks/UseEffect/SimpleUseEffect";
import ComponentC from "./Hooks/UseContext/ComponentC";
import { Provider } from "./Hooks/UseContext/UserContext";

import ConditionalEffect from "./Hooks/UseEffect/ConditionalEffect";
import EffectOnlyOnce from "./Hooks/UseEffect/EffectOnlyOnce";
import EffectDep from "./Hooks/UseEffect/EffectDep";
import FetchOne from "./Hooks/UseEffect/FetchOne";

import SimpleReducer from "./Hooks/UseReducer/SimpleReducer";
import TestComponent from "./Components/TestComponent";

import ParentComponent from "./Hooks/UseCallback/ParentComponent";
import UseMemo from "./Hooks/UseMemo/UseMemo";
import UseRef from "./Hooks/UseRef/UseRef";
import Titleone from "./Hooks/CustomHooks/Titleone";
import Titletwo from "./Hooks/CustomHooks/Titletwo";

//TestComponents
import SimpleFunctional from "./TestComponents/SimpleFunctional";
import SimpleClass from "./TestComponents/SimpleClass";
import SimpleFunctionalProps from "./TestComponents/SimpleFunctionalProps";
import SimpleClassProps from "./TestComponents/SimpleClassProps";
import SimpleClassState from "./TestComponents/SimpleClassState";
import SimpleSetStateClass from "./TestComponents/SimpleSetStateClass";
import {
  DestructureFunctionalProps1,
  DestructureFunctionalProps2
} from "./TestComponents/DestructureFunctionalProps";
import DestructureClassProps from "./TestComponents/DestructureClassProps";
import FunctionalEventHandling from "./TestComponents/FunctionalEventHandling";
import ClassEventHandling from "./TestComponents/ClassEventHandling";
import {
  BindingEvent1,
  BindingEvent2,
  BindingEvent3
} from "./TestComponents/BindingEvents";

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StrictMode>
    <BindingEvent3 />
    <BindingEvent2 />
    <BindingEvent1 />
    <ClassEventHandling />
    <FunctionalEventHandling />
    <DestructureClassProps fruitName="Apple" price="234.45" />
    <DestructureFunctionalProps2 name="Suma" location="karnataka" />
    <DestructureFunctionalProps1 name="Vijay" location="Haryana" />
    <SimpleSetStateClass />
    <SimpleClassState />
    <SimpleClassProps heroName="Vijay" />
    <SimpleFunctionalProps name="Keerthivasan" />
    <SimpleClass />
    <SimpleFunctional />
    <Titleone />
    <Titletwo />
    <UseRef />
    <UseMemo />
    <ParentComponent />
    <SimpleReducer />
    <TestComponent />
    <FetchOne />
    <EffectDep />
    <EffectOnlyOnce />
    <ConditionalEffect />
    <Provider>
      <ComponentC value="Harish kalyan" />
    </Provider>
    <SimpleUseEffect />
    <ObjectState />
    <PrevState />
    <SimpleUseState />
    <App />
  </StrictMode>,
  rootElement
);
