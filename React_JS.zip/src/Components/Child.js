import React from "react";
// function Child({ person }) {
//   return (
//     <h2>
//       I am {person.name} whose id is {person.id}
//     </h2>
//   );
// }

function Child(props) {
  return <button onClick={props.testProps}>Are you good ?</button>;
}
export default Child;
