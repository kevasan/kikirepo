import React, { Component } from "react";

class Classhelloworld extends Component {
  render() {
    return <h1>Hello world using class component.</h1>;
  }
}

export default Classhelloworld;
