import React, { Component } from "react";

class Classprops extends Component {
  render() {
    return (
      <h1>
        I am {this.props.name} & I know {this.props.program}
      </h1>
    );
  }
}

export default Classprops;
