import React from "react";

// const Destructureprops = ({ name, heroName }) => {
//   return (
//     <h1>
//       I am {name} & I like {heroName}
//     </h1>
//   );
// };

//another way of destructuring props

const Destructureprops = (props) => {
  const { name, heroName } = props;
  return (
    <h1>
      I am {name} & I like {heroName}
    </h1>
  );
};
export default Destructureprops;
