import React from "react";

function Eventhandling() {
  function ClickHandler() {
    alert("Button Clicked");
  }

  return (
    <div>
      <button onClick={ClickHandler}>Click me</button>
    </div>
  );
}

export default Eventhandling;
