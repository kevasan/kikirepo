import React, { Component } from "react";

class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: ""
    };
  }
  enterUserValue = () => {
    this.setState({
      name: event.target.value
    });
  };

  handleSubmit = (event) => {
    alert(`${this.state.name} is updated`);
    event.preventDefault();
  };

  render() {
    return (
      <React.Fragment>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            name="Name"
            value={this.state.name}
            onChange={this.enterUserValue}
          />
          <button>submit</button>
        </form>
      </React.Fragment>
    );
  }
}
export default Form;
