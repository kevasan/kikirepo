import React from "react";

const Functionalprops = (props) => {
  return (
    <div>
      <p>
        I am {props.name} and I know {props.program}
      </p>
    </div>
  );
};

export default Functionalprops;
