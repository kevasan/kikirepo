import React from "react";

function Helloworld() {
  return <h1>Hello world using functional component</h1>;
}

export default Helloworld;
