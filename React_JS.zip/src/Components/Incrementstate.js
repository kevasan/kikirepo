import React, { Component } from "react";

class Incrementstate extends Component {
  constructor() {
    super();
    this.state = {
      count: 0
    };
  }

  IncrementValue() {
    this.setState(
      {
        count: this.state.count + 1
      },
      () => {
        console.log(this.state.count);
      }
    );
  }

  render() {
    return (
      <div>
        <h2>Count: {this.state.count}</h2>
        <button onClick={() => this.IncrementValue()}>Increment</button>
      </div>
    );
  }
}

export default Incrementstate;
