import React from "react";

// function Lists(){
//   const names = ['Keerthi','Parvesh','Laksha']
//   const namesList = names.map(name=><h2>{name}</h2>)
//   return (
//     <div>{namesList}</div>
//   )
// }

import Child from "./Child.js";

function Lists() {
  const persons = [
    {
      id: 101,
      name: "Keerthi"
    },
    {
      id: 102,
      name: "vasan"
    },
    {
      id: 103,
      name: "krishna"
    }
  ];

  const personslist = persons.map((person) => (
    <Child key={person.id} person={person} />
  ));
  return <div>{personslist}</div>;
}

export default Lists;
