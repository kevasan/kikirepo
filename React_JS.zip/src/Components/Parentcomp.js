import React, { Component } from "react";

class Parentcomp extends Component {
  constructor() {
    super();
    this.state = {
      name: "Keerthivasan Mani"
    };
  }

  render() {}
}
