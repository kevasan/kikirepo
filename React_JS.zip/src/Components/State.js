import React, { Component } from "react";

class State extends Component {
  constructor() {
    super();
    this.state = {
      message: "Hey Guys, visit our site here"
    };
  }

  changeMessage() {
    this.setState({
      message: "Thank for visting our site"
    });
  }

  render() {
    return (
      <div>
        <h1>{this.state.message}</h1>
        <button onClick={() => this.changeMessage()}>Visit Here</button>
      </div>
    );
  }
}

export default State;
