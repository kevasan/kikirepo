// import React from "react";
import React, { Component } from "react";

const heading = {
  color: "blue",
  fontSize: "32px",
  textDecoration: "underline"
};

// function Stylesheet() {
//   return (
//     <div>
//       <h2 style={heading}>Hello Keerthivasan</h2>
//       <p style={{color:"red",fontSize:"32px",fontWeight:"bold"}}>inmlinestyle checking</p>
//       </div>
//   );
// }

class Stylesheet extends Component {
  render() {
    return <h1 style={heading}>hello</h1>;
  }
}
export default Stylesheet;
