import React, { Component } from "react";
import Child from "./Child";

// class Test extends Component {
//   render() {
//     const fruits = ["Apple", "Banana", "Cucumber"];
//     const fruitsList = fruits.map((fruit) => <h1>Fruit Name: {fruit}</h1>);

//     const veges = [
//       {
//         name: "Brinjal",
//         color: "violet",
//         price: 200
//       },
//       {
//         name: "Potato",
//         color: "Brown",
//         price: 20
//       },
//       {
//         name: "Tomato",
//         color: "red",
//         price: 50
//       }
//     ];

//     const vegList = veges.map((veg) => (
//       <h1>
//         the {veg.name} whose color is {veg.color} and finally price is{" "}
//         {veg.price}
//       </h1>
//     ));

//     return (
//       <React.Fragment>
//         {/* <div>{fruitsList}</div>
//         <div>{vegList}</div> */}
//         <Child testPropsOne={fruitsList} />
//         <Child testPropsTwo={vegList} />
//       </React.Fragment>
//     );
//   }
// }

class Test extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "Hey guys, How are you"
    };
    this.checkHealth = this.checkHealth.bind(this);
  }

  checkHealth = () => {
    this.setState({
      message: "Yeah I m pretty good"
    });
  };

  render() {
    return (
      <React.Fragment>
        <p>{this.state.message}</p>
        <Child testProps={this.checkHealth} />
      </React.Fragment>
    );
  }
}

export default Test;
