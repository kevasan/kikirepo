import React, { Component } from "react";
import ComponentE from "./ComponentE.js";

class ComponentC extends Component {
  render() {
    return <ComponentE />;
  }
}
export default ComponentC;
