import React, { Component } from "react";
import ComponentF from "./ComponentF.js";

import Context from "./Context.js";

class ComponentE extends Component {
  render() {
    return (
      <div>
        <p>Hello {this.context}</p>
        <ComponentF />;
      </div>
    );
  }
}

ComponentE.contextType = Context;

export default ComponentE;
