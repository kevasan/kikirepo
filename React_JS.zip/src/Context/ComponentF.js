import React, { Component } from "react";
import { ContextConsumer } from "./Context.js";

class ComponentF extends Component {
  render() {
    return (
      <ContextConsumer>
        {(username) => {
          return <h1>hello {username}</h1>;
        }}
      </ContextConsumer>
    );
  }
}

export default ComponentF;
