import React from "react";
import ReactDOM from "react-dom";

const Portal = () => {
  return ReactDOM.createPortal(
    <h1>Hey I am a new portal</h1>,
    document.getElementById("portal-root")
  );
};
export default Portal;
