// import React from 'react'

// export const Common = () =>{
//   return(
//     <React.Fragment>
//       <h1>Hello Curly brace</h1>
//     </React.Fragment>
//   )
// }

// export const Common1 = () =>{
//   return (
//      <React.Fragment>
//       <h1>Hello Curly brace = Common1</h1>
//     </React.Fragment>
//   )
// }

import React,{Component} from 'react'

class Common extends Component{
  constructor(props){
    super(props)
  this.refCheck = React.createRef()
  this.cbref = null
  this.setcbref = (element) =>{
      this.cbref = element
  }
  }

componentDidMount(){
  if(this.cbref){
  this.cbref.focus()
  }
}

  render(){
    return(
      <React.Fragment>
      <form>
      <input type="text" ref={this.setcbref} />
      </form>
      </React.Fragment>
    )
  }
}

export default Common;

