import React from 'react'

function Memo(props){
  console.log("Memo Component")
  return(
    <h1>Memo Component {props.name}</h1>
  )
}
export default React.memo(Memo);