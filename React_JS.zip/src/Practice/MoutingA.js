import React, { Component } from "react";

import MoutingB from "./MoutingB.js";

class MoutingA extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "Keerthi"
    };
    console.log("A: Construcor Method");
  }

  componentDidMount() {
    console.log("A: Did Mount method");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("A: Deriveed Method");
    return null;
  }
  render() {
    console.log("A: Render Method");
    return (
      <div>
        <h1>Lifecyle A Method</h1>
        <MoutingB />
      </div>
    );
  }
}
export default MoutingA;
