import React, { Component } from "react";

class MoutingB extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "Keerthi"
    };
    console.log("B: Construcor Method");
  }

  componentDidMount() {
    console.log("B: Did Mount method");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("B: Deriveed Method");
    return null;
  }
  render() {
    console.log("B: Render Method");
    return <h1>Lifecyle B Method</h1>;
  }
}
export default MoutingB;
