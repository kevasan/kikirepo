import React,{Component} from 'react'

import Refchild from "./Refchild.js"

class ParentRef extends Component{
  constructor(props){
    super(props)
    this.parentRef = React.createRef()
  }

clickHandler = () =>{
  this.parentRef.current.focus()
}

  render(){
    return (
    <div>
    <Refchild ref={this.parentRef} />
    <button onClick={this.clickHandler}>focus inout</button>
    </div>
    )
  }
}

export default ParentRef;