import React,{Component} from 'react'

// import Regcompo from "./Regcompo.js"
// import Purecomp from "./Purecomp.js"
import Memo from "./Memo.js"

class Parentcomp extends Component{
  constructor(props){
    super(props)
      this.state = {
          name: "Keerthi"
      } 
  }
    componentDidMount() {
      setInterval(() => {
        this.setState({
          name: 'keerthi'
        })
    } , 2000)
  }

  render(){
    console.log("*****Parent Component****")
    return(
      <React.Fragment>
      <Memo name={this.state.name} />
      {/* <Purecomp propsname={this.state.name}/>
      <Regcompo propsname={this.state.name}/> */}
      </React.Fragment>
    )
  }
}
export default Parentcomp;