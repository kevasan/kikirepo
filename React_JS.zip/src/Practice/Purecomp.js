import React,{PureComponent} from 'react'

class Purecomp extends PureComponent{
    
    render(){
      console.log("Pure Component")
      return (
        <h1>Pure Component Testing and also {this.props.propsname}</h1>
      )
    }
}

export default Purecomp;