import React from 'react'

const Refchild = React.forwardRef((props,ref)=>{
  return <input type="text" re={ref} />
})
export default Refchild;