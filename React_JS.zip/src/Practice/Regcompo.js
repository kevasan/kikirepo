import React,{Component} from 'react'

class Regcompo extends Component{
    
    render(){
      console.log("Regular Component")
      return <h1>Regular Component Testing and also {this.props.propsname}</h1>
    }
}

export default Regcompo;