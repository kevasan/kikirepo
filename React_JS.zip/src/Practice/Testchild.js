import React from "react";

function Testchild(props) {
  return <button onClick={props.testProps}>change text</button>;
}

export default Testchild;
