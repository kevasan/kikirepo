import React from "react";

function Testevents() {
  function displayMessage(test) {
    alert(test);
  }
  return (
    <button onClick={() => displayMessage("Hello Keerthivasan how are you ?")}>
      Click me to test
    </button>
  );
}

export default Testevents;
