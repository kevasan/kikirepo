import React, { Component } from "react";
import Testchild from "./Testchild";

class Testparent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "Hey I am original text"
    };
    this.changeText = this.changeText.bind(this);
  }

  changeText = () => {
    this.setState({
      message: "Hey I am good now - changed text"
    });
  };

  render() {
    return (
      <div>
        <p>{this.state.message}</p>
        <Testchild testProps={this.changeText} />
      </div>
    );
  }
}
export default Testparent;
