import React from "react";

//props creating by normal function
// function Testprops(props) {
//   return (
//     <div>
//       <h1>Testing props!!! - Hello {props.name}</h1>
//     </div>
//   );
// }

//Props creation using arrow function
const Testprops = (props) => {
  const { name } = props;
  return (
    <div>
      <h1>Testing props using arrow function!!! - Hello {name}</h1>
    </div>
  );
};

export default Testprops;
