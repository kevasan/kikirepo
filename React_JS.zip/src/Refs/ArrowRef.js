import React, { Component } from "react";

class ArrowRef extends Component {
  constructor(props) {
    super(props);
    // this.inputRef = React.createRef();
    this.cbRef = null;
    this.setcbRef = (element) => {
      this.cbRef = element;
    };
  }

  componentDidMount() {
    if (this.cbRef) {
      this.cbRef.focus();
    }
  }

  render() {
    return (
      <React.Fragment>
        <input type="text" ref={this.inputRef} />
        <input type="text" ref={this.setcbRef} />
      </React.Fragment>
    );
  }
}
export default ArrowRef;
