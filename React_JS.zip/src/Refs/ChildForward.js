import React from "react";

// const ChildForward = React.forwardRef((props, ref) => {
//   return <input type="text" ref={ref} />;
// });

const ChildForward = React.forwardRef((props, ref) => {
  return <input type="text" ref={ref} />;
});

export default ChildForward;
