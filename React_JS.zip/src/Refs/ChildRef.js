import React, { Component } from "react";

class ChildRef extends Component {
  constructor(props) {
    super(props);
    this.childRef = React.createRef();
  }
  focusInput() {
    this.childRef.current.focus();
  }
  render() {
    return <input type="text" ref={this.childRef} />;
  }
}

export default ChildRef;
