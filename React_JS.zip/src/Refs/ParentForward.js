import React, { Component } from "react";
import ChildForward from "./ChildForward.js";

class ParentForward extends Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }
  clickHandler = () => {
    this.inputRef.current.focus();
  };
  render() {
    return (
      <React.Fragment>
        <ChildForward ref={this.inputRef} />
        <button onClick={this.clickHandler}>click focus</button>
      </React.Fragment>
    );
  }
}
export default ParentForward;
