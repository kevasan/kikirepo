import React, { Component } from "react";

import ChildRef from "./ChildRef.js";

class ParentRef extends Component {
  constructor(props) {
    super(props);
    this.parentRef = React.createRef();
  }

  clickHandler = () => {
    this.parentRef.current.focusInput();
  };

  render() {
    return (
      <React.Fragment>
        <ChildRef ref={this.parentRef} />
        <button onClick={this.clickHandler}>REF WITH CLASS</button>
      </React.Fragment>
    );
  }
}
export default ParentRef;
