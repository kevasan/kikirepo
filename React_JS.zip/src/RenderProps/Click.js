import React, { Component } from "react";

class Click extends Component {
  render() {
    const { countvalue, incrementvalue } = this.props;
    return <button onClick={incrementvalue}>Click me {countvalue}</button>;
  }
}
export default Click;
