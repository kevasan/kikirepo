import React, { Component } from "react";

class Hover extends Component {
  render() {
    const { countvalue, incrementvalue } = this.props;
    return <button onMouseOver={incrementvalue}>Click me {countvalue}</button>;
  }
}
export default Hover;
