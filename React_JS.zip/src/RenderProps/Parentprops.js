import React, { Component } from "react";
import Click from "./Click.js";
class Parentprops extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }

  clickHandler = () => {
    this.setState({
      count: this.state.count + 1
    });
  };

  render() {
    return (
      <React.Fragment>
        {this.props.render(this.state.count, this.clickHandler)}
      </React.Fragment>
    );
  }
}
export default Parentprops;
