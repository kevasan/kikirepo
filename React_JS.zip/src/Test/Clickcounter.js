import React, { Component } from "react";

class Clickcounter extends Component {
  render() {
    const { countvalue, incrementvalue } = this.props;
    return (
      <button onClick={incrementvalue}>Click me to count {countvalue}</button>
    );
  }
}
export default Clickcounter;
