import React, { Component } from "react";

class Commoncounter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }

  handleClick = () => {
    this.setState({
      count: this.state.count + 1
    });
  };

  render() {
    return (
      <div className="test-counter">
        {this.props.render(this.state.count, this.handleClick)}
      </div>
    );
  }
}
export default Commoncounter;
