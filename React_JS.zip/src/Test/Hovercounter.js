import React, { Component } from "react";

class Hovercounter extends Component {
  render() {
    return (
      <button onMouseOver={this.handleClick}>
        Hover me to count {this.state.count}
      </button>
    );
  }
}
export default Hovercounter;
