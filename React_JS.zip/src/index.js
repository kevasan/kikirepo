import { StrictMode } from "react";
import ReactDOM from "react-dom";

import App from "./App";
import Test from "./Components/Test";
import Classhelloworld from "./Components/Classhelloworld";
import Helloworld from "./Components/Helloworld";
import Functionalprops from "./Components/Functionalprops";
import Classprops from "./Components/Classprops";
import State from "./Components/State";
import Eventhandling from "./Components/Eventhandling";
import Destructureprops from "./Components/Destructureprops";
import Incrementstate from "./Components/Incrementstate";
import Lists from "./Components/Lists";
import Stylesheet from "./Components/Stylesheet";
import Form from "./Components/Form";

import Testprops from "./Practice/Testprops";
import Testevents from "./Practice/Testevents";
import Testparent from "./Practice/Testparent";
import MoutingA from "./Practice/MoutingA";
import Purecomp from "./Practice/Purecomp";
import Common from "./Practice/Common";
import ParentRef from "./Practice/ParentRef";
import Parentcomp from "./Practice/Parentcomp";

import GeneralRef from "./Refs/GeneralRef";
import ArrowRef from "./Refs/ArrowRef";
import ParentRefs from "./Refs/ParentRef";
import ParentForward from "./Refs/ParentForward";

import Click from "./RenderProps/Click";
import Hover from "./RenderProps/Hover";

import Parentprops from "./RenderProps/Parentprops";

import { ContextProvider } from "./Context/Context.js";
import ComponentC from "./Context/ComponentC";

import Portal from "./Portals/Portal";

import Clickcounter from "./Test/Clickcounter";
import Hovercounter from "./Test/Hovercounter";
import Commoncounter from "./Test/Commoncounter";
// function Newprops(props){
//   return <h1>New props testing: {props.heroname}</h1>
// }

// const xelement = <Newprops heroname = "Vijay Keerthi"/>
// ReactDOM.render(xelement,document.getElementById("root"))

const rootElement = document.getElementById("root");
ReactDOM.render(
  <StrictMode>
    <Portal />
    <Commoncounter
      render={(count, increment) => (
        <Clickcounter countvalue={count} incrementvalue={increment} />
      )}
    />
    {/* <Clickcounter />
    <Hovercounter /> */}
    {/* <ContextProvider value="Lakshashree">
      <ComponentC />
    </ContextProvider> */}
    {/* 
    <Parentprops
      render={(count, increment) => (
        <Click countvalue={count} incrementvalue={increment} />
      )}
    />
    <Parentprops
      render={(count, increment) => (
        <Hover countvalue={count} incrementvalue={increment} />
      )}
    /> */}
    {/* <Hover />
    <Click /> */}
    <ParentForward />
    {/* <ArrowRef /> */}
    <ParentRefs />
    {/* <GeneralRef /> */}
    {/* <MoutingA />
    <ParentRef />
    <Parentcomp />
    <Purecomp />
    <Common />
    <Form />
    <Test />
    <Testparent />
    <Testevents />
    <Testprops name="Keerthivasan" />
    <Stylesheet />
    <Lists />
    <Eventhandling />
    <Destructureprops name="Keerthi" heroName="Vijay" />
    <Incrementstate />
    <State />
    <Classprops name="Vasan" program="Angular" />
    <Functionalprops name="Keerthi" program="python"></Functionalprops>
    <App />
    <Helloworld />
    <Classhelloworld /> */}
  </StrictMode>,
  rootElement
);
