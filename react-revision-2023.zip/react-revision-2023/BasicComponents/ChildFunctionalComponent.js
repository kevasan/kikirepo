import React from "react"

const ChildFunctionalComponent = (props)=>{
    return(
        <div>
            <p>Rendering parent's component's props here. I mean I have passed the 
                parent state as a prop to child component
                that is .... {props.parentProps}
            </p>
            <button onClick={()=>{props.clickHandler("Suresh Ragul")}}>I am a child component</button>
        </div>
    )
}

export default ChildFunctionalComponent