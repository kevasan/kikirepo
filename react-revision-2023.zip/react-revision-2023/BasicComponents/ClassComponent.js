
import React, { Component } from "react";

export class ClassComponent extends Component {
    render() {
        return (
            <div>
                <h1>Simple Class Component</h1>
                <p>This will component will help you in creating a simple class component</p>
            </div>
        )
    }
}