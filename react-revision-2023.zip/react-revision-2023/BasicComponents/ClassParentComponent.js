import React,{Component} from "react"
import ChildFunctionalComponent from "./ChildFunctionalComponent"


class ClassParentComponent extends Component{
    constructor(){
        super()
        this.state = {
            message: "Hello I am a right !"
        }
    }

    clickHandler = (childprops)=>{
        alert(`hey I am Keerthivasan who is friend of ${childprops}`)
    }

    render(){
        return(
            <div>
                <h3>This is my Parent Component</h3>
                <ChildFunctionalComponent parentProps = {this.state.message} clickHandler={this.clickHandler}/>
            </div>
        )
    }
}

export default ClassParentComponent