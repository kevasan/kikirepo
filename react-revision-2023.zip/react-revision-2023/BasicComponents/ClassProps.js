

import React, { Component } from "react"

export class ClassProps extends Component {
    render() {
        const {name, age, favorites, bankDetails:{bankName, bankBranch}, children} = this.props
        const favorites_result = favorites.map((favorite)=>(<li>{favorite}</li>))
        return (
            <div>
                <h1>Simple Class Component w/ Props</h1>
                <ul>
                    <li>Name: {name}</li>
                    <li>Age: {age}</li>
                </ul>
                <ol>
                    {favorites_result}
                </ol>
                <dl>
                    <dt>Bank Name : {bankName}</dt>
                    <dd>Bank Branch: {bankBranch}</dd>
                </dl>
                <div>
                    {children}
                </div>
            </div>
        )
    }
}