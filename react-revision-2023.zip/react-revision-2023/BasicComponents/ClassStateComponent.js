
import React, { Component } from "react";

export class ClassStateComponent extends Component {

    constructor() {
        super()
        this.state = {
            message: "Welcome to our React Community!",
            counter: 0
        }
    }

    UpdateMessage = () => {
        this.setState({
            message: "Thanks for visiting our site..."
        })
    }

    ClickCounter = () => {
        // this.state.counter = this.state.counter + 1
        this.setState((prevState => (
            {
                counter: prevState.counter + 1
            }
        )), () => {
            console.log("Counter : ", this.state.counter)
        })
        // console.log("Counter : ", this.state.counter)
    }

    IncrementTwice = () => {
        this.ClickCounter()
        this.ClickCounter()
    }

    render() {
        return (
            <div>
                <h1>State Initialization & setState() Method Implementation</h1>
                <div>
                    <h2>1. State Initialization</h2>
                    <h3>Rendering a simple welcome message using state in Class Component</h3>
                    <p>{this.state.message}</p>
                </div>

                <div>
                    <h2>2. Changing the current state value to the updated value by clicking the button</h2>
                    <p>{this.state.message}</p>
                    <button onClick={this.UpdateMessage}>To check the updated state value</button>
                </div>

                <div>
                    <h2>3. Counter Functionality</h2>
                    <p>Counter Value : {this.state.counter}</p>
                    <button onClick={this.ClickCounter}>Click me to increment counter</button>
                </div>

                <div>
                    <h2>4. Increment Twice the counter</h2>
                    <p>Counter Value : {this.state.counter}</p>
                    <button onClick={this.IncrementTwice}>Click me to increment counter</button>
                </div>
            </div>
        )
    }
}