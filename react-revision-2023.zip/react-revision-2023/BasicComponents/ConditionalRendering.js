
import React, { Component } from "react";

export class ConditionalStatement extends Component {

    constructor() {
        super()
        this.state = {
            x: 10
        }
    }

    render() {
        if (this.state.x === 10) {
            return (
                <div>
                    <h1>1. Conditional Statement - if/else</h1>
                    <h3>True Statement is encountered!</h3>
                </div>
            )
        }
        else {
            return (
                <div>
                    <h1>1. Conditional Statement - if/else</h1>
                    <h3>False Statement is encountered!</h3>
                </div>
            )
        }

    }
}

export class ElementVariables extends Component {
    constructor() {
        super()
        this.state = {
            y: 25
        }
    }
    render() {
        let someValue;

        if (this.state.y === 25) {
            someValue = (
                <div>
                    <h1>2. Element Variables</h1>
                    <h3>True Element Variables are encountered!</h3>
                </div>)
        }
        else {
            someValue = (
                <div>
                    <h1>2. Element Variables</h1>
                    <h3>False Element Variables are encountered!</h3>
                </div>)
        }
        return (
            <div>
                {someValue}
            </div>
        )
    }
}

export class TernaryOperator extends Component {
    constructor() {
        super()
        this.state = {
            text: "success"
        }
    }
    render() {
        return this.state.text === "success" ? (
            <div>
                <h1>3. Ternary Operator</h1>
                <h3>True Ternary Statement is encountered!</h3>
            </div>
        ) : (
            <div>
                <h1>3. Ternary Operator</h1>
                <h3>False Ternary Statement is encountered!</h3>
            </div>
        )
    }
}

export class ShortCircuitOperator extends Component{
    constructor(){
        super()
        this.state = {
            isCompleted:true
        }
    }
    render(){
        return this.state.isCompleted && (
            <div>
                <h1>4. Short Circuit Operator</h1>
                <h3>I am completed!</h3>
            </div>
        )
    }
}