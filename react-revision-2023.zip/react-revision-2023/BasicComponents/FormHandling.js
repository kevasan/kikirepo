
import React, { Component } from "react";

export class FormHandling extends Component {

    constructor() {
        super()
        this.state = {
            username: "",
            password: "",
            gender: "",
            favorites: "",
        }
    }

    GetInputValue = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        })
    }

    SubmitHandler = (event) => {
        alert(`
            Username : ${this.state.username}
            Password : ${this.state.password}
            Gender : ${this.state.gender}
            Favorites : ${this.state.favorites}
        `)
        event.preventDefault()
    }


    render() {
        return (
            <React.Fragment>
                <h1>Form Handling Concepts</h1>
                <form onSubmit={this.SubmitHandler}>
                    <label htmlFor="username">Enter the username: </label>
                    <br />
                    <input type="text" id="username" name="username" value={this.state.username}
                        onChange={this.GetInputValue} />
                    <br />

                    <label htmlFor="password">Enter the password: </label>
                    <br />
                    <input type="password" id="password" name="password" value={this.state.password}
                        onChange={this.GetInputValue} />
                    <br />

                    <label htmlFor="gender-male">Choose the gender: </label>
                    <br />
                    <input type="radio" id="gender-male" name="gender" value={"male"}
                        checked={this.state.gender === "male"}
                        onChange={this.GetInputValue} />
                    <span>Male</span>
                    <br />

                    <input type="radio" id="gender-female" name="gender" value={"female"}
                        checked={this.state.gender === "female"}
                        onChange={this.GetInputValue} />
                    <span>Female</span>
                    <br />

                    <label htmlFor="">Choose the favorites: </label>
                    <br />
                    <input type="checkbox" id="favorites" name="favorites" value={"cricket"}
                        checked={this.state.favorites === "cricket"}
                        onChange={this.GetInputValue} />
                    <span>Cricket</span>
                    <br />

                    <input type="checkbox" id="favorites" name="favorites" value={"football"}
                        checked={this.state.favorites === "football"}
                        onChange={this.GetInputValue} />
                    <span>Foot Ball</span>
                    <br />
                    <input type="submit" />
                </form>
            </React.Fragment>

        )
    }
}