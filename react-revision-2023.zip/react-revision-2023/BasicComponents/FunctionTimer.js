import React, { useEffect, useRef, useState } from "react"

const FunctionTimer = () => {

    const [timer, setTimer] = useState(0)

    const interval = useRef()

    useEffect(() => {
        // const interval = setInterval(() => { setTimer(timer => timer + 1) }, 1000)
         interval.current = setInterval(() => { setTimer(timer => timer + 1) }, 1000)
        return () => {
            // clearInterval(interval)
            clearInterval(interval.current)
        }
    }, [])


    return (
        <div>
            <h3>Timer Value : {timer}</h3>
            <button onClick={() => { clearInterval(interval.current) }}>Function Clear Interval</button>
            {/* <button onClick={() => { clearInterval(interval) }}>Function Clear Interval</button> */}
        </div>
    )
}

export default FunctionTimer