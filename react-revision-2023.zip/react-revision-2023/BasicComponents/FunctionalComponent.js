
import React from "react";

export const FunctionalComponent = () => {
    return (
        <div>
            <h1>Simple Functional Component</h1>
            <p>This will component will help you in creating a simple functional component using an arrow function</p>
        </div>
    )
}
