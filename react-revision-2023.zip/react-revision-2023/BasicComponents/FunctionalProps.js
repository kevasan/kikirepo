
import React from "react"

export const FunctionalProps = ({ name, age, hobbies, details:{personName, personEmail}, children }) => {
    const hobby_result = hobbies.map((hobby) => (<li>{hobby}</li>))
    return (
        <div>
            <h1>Functional Component w/ props</h1>
            <ul>
                <li>Name : {name}</li>
                <li>Age: {age}</li>
            </ul>
            <ol>
                {hobby_result}
            </ol>
            <dl>
                <dt>{personName}</dt>
                <dd>{personEmail}</dd>
            </dl>
            <div>
                {children}
            </div>
        </div>
    )
}