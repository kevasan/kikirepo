import React, { Component } from "react";
import axios from "axios"

class HTTPRequestComponent extends Component {
    constructor() {
        super()
        this.state = {
            posts: []
        }
    }

    componentDidMount() {
        axios.get("https://jsonplaceholder.typicode.com/users")
            .then((response) => {
                this.setState({
                    posts: response.data
                })
            })
            .catch((error) => {
                console.log(error)
            })
    }

    render() {
        const users = this.state.posts
        const result = users.map((user) => {
            return (
                <tr>
                    <td>{user.username}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                </tr>
            )
        })
        return (
            <div>
                <h1>Fetching Data throuh API calls</h1>
                <table>
                    <thead>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Email</th>
                    </thead>
                    <tbody>
                        {
                            result
                        }
                    </tbody>
                </table>
            </div>
        )
    }
}

export default HTTPRequestComponent