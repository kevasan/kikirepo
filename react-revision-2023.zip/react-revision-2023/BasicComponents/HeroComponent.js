
import React, { Component } from "react";

export class HeroComponent extends Component {
    render() {
        return (
            <div>
                <h1>Rendering Hero's</h1>
                <p>{this.props.x}</p>
            </div>
        )

    }
}