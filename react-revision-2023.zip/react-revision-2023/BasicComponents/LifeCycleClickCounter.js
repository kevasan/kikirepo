import React, { Component } from "react"

class LifeCycleClickCounter extends Component {

    constructor() {
        super()
        this.state = {
            count: 0,
            name: ""
        }
    }

    IncrementCount = () => {
        this.setState({
            count: this.state.count + 1
        })
    }

    componentDidMount() {
        document.title = `Document Count is : ${this.state.count}`
    }

    componentDidUpdate(prevProps, prevState) {
        console.log("Updating the document title.....")
        if (prevState.count !== this.state.count) {
            document.title = `Document Count is : ${this.state.count}`
        }

    }

    changeHandler = (event) => {
        this.setState({
            name: event.target.value
        })
    }

    render() {
        return (
            <React.Fragment>
                <input type={"text"} value={this.state.name} onChange={this.changeHandler} />
                <button onClick={this.IncrementCount}>Click me to count: {this.state.count}</button>
            </React.Fragment>
        )
    }

}

export default LifeCycleClickCounter