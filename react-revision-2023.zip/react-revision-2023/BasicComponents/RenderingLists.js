

import React from "react";

export const RenderingLists = () => {
    const fruits = ["Apple", "Banana", "Cucumber", "Dates", "Grapes", "Papaya"]
    const fruitlist = fruits.map((fruit) => (<li>{fruit}</li>))
    return (
        <div>
            <h1>Rendering Fruits Lists</h1>
            <ul>
                {fruitlist}
            </ul>
        </div>
    )
}