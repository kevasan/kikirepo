import React from "react"

const Button = ({method, children})=>{
    console.log(`${children} is clicked`)
    return (
        <div>
            <button onClick={method}>{children}</button>
        </div>
    )
}

export default React.memo(Button)