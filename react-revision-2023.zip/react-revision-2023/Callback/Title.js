import React from "react"

const Title = ()=>{
    console.log("Titel Component...")
    return (
        <div>
            <h1>Title Component</h1>
        </div>
    )
}

export default React.memo(Title)