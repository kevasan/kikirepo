

import React from "react"

const UserContext = React.createContext()
const UserProvider = UserContext.Provider
const UserConsumer = UserContext.Consumer

const ChannelContext = React.createContext()
const ChannelProvider = ChannelContext.Provider
const ChannelConsumer = ChannelContext.Consumer

export { UserContext, UserConsumer, UserProvider, ChannelContext, ChannelProvider, ChannelConsumer }