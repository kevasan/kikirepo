


import React from "react";
import ComponentC from "./ComponentC";
import { UserContext } from "./ClassContext";

class ComponentB extends React.Component {
    // static contextType = UserContext
    render() {
        return (
            <div>
                <h1>Component B - {this.context}</h1>
                <ComponentC />
            </div>
        )
    }

}

ComponentB.contextType = UserContext
export default ComponentB

