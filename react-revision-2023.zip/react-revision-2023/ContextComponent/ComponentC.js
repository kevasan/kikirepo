

import React, { useContext } from "react";
import { ChannelConsumer, ChannelContext, UserConsumer, UserContext } from "./ClassContext";

const ComponentC = () => {
    const username = useContext(UserContext)
    const channelname = useContext(ChannelContext)
    return (
        // <UserConsumer>
        //     {
        //         (username) => {
        //             return (
        //                 <ChannelConsumer>
        //                     {
        //                         (channelname) => {
        //                             return (
        //                                 <div>
        //                                     <h1>Component C</h1>
        //                                     <p>Username : {username}</p>
        //                                     <p>Channel Name : {channelname}</p>
        //                                 </div>
        //                             )
        //                         }
        //                     }
        //                 </ChannelConsumer>
        //             )
        //         }
        //     }
        // </UserConsumer>
        <div>
            <h1>Hooks Implementation of useContext</h1>
            <p>{username}****{channelname}</p>
        </div>
    )
}

export default ComponentC