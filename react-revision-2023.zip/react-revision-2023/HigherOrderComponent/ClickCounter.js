
import React, { Component } from "react";
import OptimizedCounter from "./OptimizedCounter";
class ClickCounter extends Component {
    render() {
        return (
            <div>
                <h1>Click Counter Functionality - Higher Order Component</h1>
                <p>Counter : {this.props.count}</p>
                <button onClick={this.props.CounterFunctionality}>Click Counter</button>
            </div>
        )
    }
}


export default OptimizedCounter(ClickCounter, 5)