

import React, { Component } from "react";
import OptimizedCounter from "./OptimizedCounter";

class HoverCounter extends Component {

    render() {
        return (
            <div>
                <h1>Hover Counter Functionality - Higher Order Component</h1>
                <p>Counter : {this.props.count}</p>
                <button onMouseOver={this.props.CounterFunctionality}>Hover Counter</button>
            </div>
        )
    }
}

export default OptimizedCounter (HoverCounter, 10)