
import React from "react"

const OptimizedCounter = (OriginalComponent, InitialValue)=>{
    class NewComponent extends React.Component{
        constructor() {
            super()
            this.state = {
                counter: 0
            }
        }
    
        IncrementCounter = () => {
            this.setState({
                counter: this.state.counter + InitialValue
            })
        }

        render(){
            return(
                <React.Fragment>
                    <OriginalComponent count={this.state.counter} 
                    CounterFunctionality={this.IncrementCounter} />
                </React.Fragment>
            )   
        }
    }
    return NewComponent
}

export default OptimizedCounter