import React, { useReducer } from "react"

const SimpleReducer = () => {

    const initialValue = 0
    const reducerMethod = (state, action) => {
        switch (action) {
            case "increment":
                return state + 1
            case "decrement":
                return state - 1
            case "reset":
                return initialValue
            default:
                return state
        }
    }

    const [count, dispatch] = useReducer(reducerMethod, initialValue)

    return (
        <div>
            <h1>Simple Reducer Functionality</h1>
            <h3>Count: {count} </h3>
            <button onClick={() => { dispatch("increment") }}>Increment</button>
            <button onClick={() => { dispatch("decrement") }}>Decrement</button>
            <button onClick={() => { dispatch("reset") }}>reset</button>
        </div>
    )

}

export default SimpleReducer