

import React, { useEffect, useState } from "react"
import axios from "axios"

export const UseEffect = () => {

    const [users, setUsers] = useState([])
    const [id, setId] = useState()
    const [buttonId, setButtonId] = useState(id)

    useEffect(
        () => {
            // axios.get(`https://jsonplaceholder.typicode.com/users`) - Step1
            // axios.get(`https://jsonplaceholder.typicode.com/users/${id}`) - step2
            axios.get(`https://jsonplaceholder.typicode.com/users/${buttonId}`)
                .then((response) => {
                    setUsers(response.data)
                })
                .catch((error) => {
                    console.log(error)
                })
        }
    )

    // const result = users.map((user)=>(<li>{user.name}:{user.website}</li>))Step1
    
    console.log("Rendering Effect Method...")
    return (
        <div>
            <h1>Simple useEffect Method Implementation</h1>
            {/* step1
             <ul>
                {result}
            </ul> */}

            <div>
                <h3>Implementation of loading data w/ input elements</h3>
                {/* <input type={"text"} value={id} onChange={(event) => { setId(event.target.value) }} />
                <p>{users.name}</p> */}

                <input type={"text"} value={id} onChange={(event) => { setId(event.target.value) }} />
                <button onClick={()=>setButtonId(id)}>Fetch Data</button>
                <p>{users.website} : {users.username}</p>
            </div>
        </div>
    )
}