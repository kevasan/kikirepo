
import React, { useState } from "react"

export const UseState = () => {

    const [counter, setCount] = useState(0)
    const IncrementCounter = () => {
        setCount(counter + 1)
    }

    const [firstName, setFirstName] = useState("")
    const UpdateName = () => {
        setFirstName("Keerthivasan")
    }

    const [person, setDetails] = useState({
        firstName: "", lastName: ""
    })

    const fruits = ["Apple", "Banana", "Cucumber"]
    const stackOfFruits = fruits.map((fruit) => { return <li>{fruit}</li> })

    const IncrementFive = ()=>{
        setCount((counter)=>counter + 1)
        setCount((counter)=>counter + 1)
        setCount((counter)=>counter + 1)
        setCount((counter)=>counter + 1)
        setCount((counter)=>counter + 1)
    }

    return (
        <div>
            <h1>Simple useState Method Implementation</h1>
            <p>Counter : {counter}</p>
            <button onClick={IncrementCounter}>Increment Counter</button>
            <label>Enter the username : </label>
            <input type={"text"} value={firstName} onChange={UpdateName} />

            <form>
                <h1>Checking the useState w/ Object Datatypes</h1>
                <label>Enter the firstName : </label>
                <input type={"text"} value={person.firstName} onChange={(event) => {
                    setDetails({ ...person, firstName: event.target.value })
                }} />

                <label>Enter the lastName : </label>
                <input type={"text"} value={person.lastName} onChange={(event) => {
                    setDetails({ ...person, lastName: event.target.value })
                }} />

                <div>
                    <p>{JSON.stringify(person)}</p>
                    <p>First Name : {person.firstName}</p>
                    <p>Last Name : {person.lastName}</p>
                </div>
            </form>

            <div>
                <h2>Fruits Lists</h2>
                <ul>
                    {stackOfFruits}
                </ul>
            </div>

            <div>
                <p>Counter: {counter}</p>
                <button onClick={IncrementFive}>Increment Five Times</button>
            </div>
        </div>
    )
}