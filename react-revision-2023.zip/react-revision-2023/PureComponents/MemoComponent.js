
import React from "react";

const MemoComponent = ({ count }) => {
    console.log("Memo Component")
    return (
        <div>
            <h1>Memo Component</h1>
            <p>Counter: {count}</p>
        </div>
    )
}

export default React.memo(MemoComponent)