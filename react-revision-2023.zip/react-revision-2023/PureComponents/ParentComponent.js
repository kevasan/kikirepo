

import React, { Component, PureComponent } from "react"
import MemoComponent from "./MemoComponent"
import { PureComponents } from "./PureComponents"
import { RegularComponent } from "./RegularComponent"

export class ParentComponent extends Component {

    constructor() {
        super()
        this.state = {
            counter: 0
        }
    }

    componentDidMount() {
        setInterval(() => {
            this.setState({
                counter: 0
            })
        }, 2000)
    }

    render() {
        console.log("Parent Component")
        return (
            <div>
                <h1>Regular Component</h1>
                <RegularComponent count={this.state.counter} />
                {/* <PureComponents count={this.state.counter} /> */}
                <MemoComponent count={this.state.counter}/>
            </div>
        )
    }
}