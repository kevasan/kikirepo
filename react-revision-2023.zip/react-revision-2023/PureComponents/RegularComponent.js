
import React, { Component } from "react"

export class RegularComponent extends Component {
    render() {
        console.log("Regular Component")
        return (
            <div>
                <h1>Regular Component</h1>
                <p>Counter : {this.props.count}</p>
            </div>
        )
    }
}