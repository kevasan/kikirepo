
import React, { Component } from "react";
import ForwardRefComponent from "./ForwardRefComponent";

class ParentForwardRef extends Component {
    constructor() {
        super()
        this.inputRef = React.createRef()
    }

    componentDidMount(){
        this.inputRef.current.focus()
    }
    render() {
        return (
            <div>
               <ForwardRefComponent ref={this.inputRef} />
            </div>
        )
    }
}

export default ParentForwardRef