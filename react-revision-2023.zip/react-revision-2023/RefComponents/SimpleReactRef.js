

import React, { Component } from "react";

class SimpleReactRef extends Component {
    constructor() {
        super()
        this.inputRef = React.createRef()
    }

    componentDidMount() {
        this.inputRef.current.focus()
    }
    render() {
        return (
            <div>
                <h1>Simple React Ref Creation</h1>
                <form>
                    <label htmlFor="username">Enter the username : </label>
                    <input type={"text"} id="username" ref={this.inputRef} />
                </form>
            </div>
        )
    }
}

export default SimpleReactRef